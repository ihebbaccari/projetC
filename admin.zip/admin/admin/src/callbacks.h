#include <gtk/gtk.h>


void
on_binscription_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_blogin_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_badmin1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bdeconx_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bdeconx2_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_bretour1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_bajout1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bchercher1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bmodifier1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_bmodifier2_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer2_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_bgestag_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bajoutsucc_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bclear1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_binscription1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_bclear2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bretour2_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_bagent1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bclient1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_binscritsucc_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_badmin1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
