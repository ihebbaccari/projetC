#include <gtk/gtk.h>
typedef struct 
{ 
	char nom[30];
	char prenom[30];
	char cin[30];
	char num[30];
	char login[30];
	char password[30];
}agent;
void ajouter_agent(agent a);
int verifier_agent(char login[30]);
void modifier_agent(agent a,char login[30]);
int supprimer_agent(agent a,char login[30]);
int rechercher_agent(agent a,char login[30]);
void afficher_agent(GtkWidget *liste);
void clear_agent();