#include <stdio.h>
#include <string.h>
#include <verife.h>
#include <admin.h>
#include <client.h>


int verifier (char login[], char password[]){
FILE *f,*b,*i;
char login1[20];char password1[20];
agent a={"med","rez","099","21234567","med","12345"},g,t;
int role;int k=-1;

/*f=fopen("users.txt","r");//ouvertur du fichier en mode lecture
if(f !=NULL) {
     while(fscanf(f,"%s %s",login1,password1)!=EOF){ //parcours du fichier
          if (strcmp(login, login1) == 0 ){
               if( strcmp(password, password1) == 0 ){
               k=1;
                                }
           } 
       }
}
fclose(f);
return k;*/
f=fopen("admin.bin","wb");
fwrite(&a,sizeof(agent),1,f);
fclose(f);
if ((strcmp(a.login,login)&&strcmp(a.password,password))==0)
{
	return 1;
}
b=fopen("agent.bin","rb+");

if (b!=NULL)
		{

			while(!(feof(b)))
				{
				fread(&g,sizeof(agent),1,b);
				if ((strcmp(g.login,login)&&strcmp(g.password,password))==0)
					{
						return 2;
					}


				}
		}
fclose(b);
i=fopen("client.bin","rb+");
if (i!=NULL)
		{
			while(!(feof(i)))
				{
				fread(&t,sizeof(agent),1,i);
				if ((strcmp(t.login,login)&&strcmp(t.password,password))==0)
					{
						return 3;
					}


				}
		}
fclose(i);
return k;
}
