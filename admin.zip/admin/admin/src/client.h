#include <gtk/gtk.h>
typedef struct 
{ 
	char nom[30];
	char prenom[30];
	char cin[30];
	char num[30];
	char login[30];
	char password[30];
}client;
void ajouter_client(client a);
int verifier_client(char login[30]);
void modifier_client(client a,char login[30]);
int supprimer_client(client a,char login[30]);
int rechercher_client(client a,char login[30]);
void afficher_client(GtkWidget *liste);
void clear_client();