#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "admin.h"
#include "verife.h"
#include "client.h"


void
on_binscription_clicked                (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window,*window2;
window=lookup_widget(object_graphique,"acceuil");
gtk_widget_hide(window);
window2=create_inscritclient();
gtk_widget_show_all(window2);
}


void
on_blogin_clicked                      (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *window1;
GtkWidget *window2;
 GtkWidget *acceuil;
 GtkWidget *input;
 GtkWidget *output;
 FILE *f;
char login[20];char password[20];
char sorti[50];
int verif;
acceuil=lookup_widget(object_graphique,"acceuil");
input=lookup_widget(object_graphique,"entry1");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input)));
input=lookup_widget(object_graphique,"entry2");
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input)));
verif=verifier(login,password);
if (verif==1){gtk_widget_hide(acceuil);
window=create_admin();
gtk_widget_show_all(window);}
if (verif==2){gtk_widget_hide(acceuil);
window1=create_agent();
gtk_widget_show_all(window1);}
if (verif==3){gtk_widget_hide(acceuil);
window2=create_client();
gtk_widget_show_all(window2);}
if (verif==-1){strcpy(sorti,"login ou password incorrect");
output=lookup_widget(object_graphique,"message1");
gtk_label_set_text(GTK_LABEL(output),sorti); }
}


void
on_badmin1_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window,*menuadm;
window=lookup_widget(object_graphique,"admin");
gtk_widget_hide(window);
menuadm=create_menuadmin();
gtk_widget_show_all(menuadm);
}


void
on_bdeconx_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"menuadmin");
gtk_widget_hide(window3);
window4=create_acceuil();
gtk_widget_show_all(window4);

}


void
on_afficher2_clicked                   (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *taff;
taff=lookup_widget(object_graphique,"taff");
afficher_agent(taff);
}



void
on_bdeconx2_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"gestagents");
gtk_widget_hide(window3);
window4=create_acceuil();
gtk_widget_show_all(window4);
}


void
on_bretour1_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"gestagents");
gtk_widget_hide(window3);
window4=create_menuadmin();
gtk_widget_show_all(window4);
}


void
on_bajout1_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
        GtkWidget *login,*nom,*prenom,*num,*cin,*password,*passwordv,*valide,*output;//ajout agent 
        agent a;
        int k=0;
        char log[30],pswd[30];
        output=lookup_widget(object_graphique,"message2");
        valide=create_ajoutsucc();
        nom=lookup_widget(object_graphique, "cnom1");
        prenom=lookup_widget(object_graphique, "cprenom1");
        num=lookup_widget(object_graphique,"ccin1");
        cin=lookup_widget(object_graphique, "cnum1");
        login=lookup_widget(object_graphique, "clogin1");
        password=lookup_widget(object_graphique, "cpassword1");
        passwordv=lookup_widget(object_graphique, "cverifpassword1");

        strcpy(a.login,gtk_entry_get_text(GTK_ENTRY(login)));
        strcpy(log,gtk_entry_get_text(GTK_ENTRY(login)));
        strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(a.num,gtk_entry_get_text(GTK_ENTRY(num)));
        strcpy(a.password,gtk_entry_get_text(GTK_ENTRY(password)));
        strcpy(pswd,gtk_entry_get_text(GTK_ENTRY(passwordv)));
        if(strcmp(a.num,"0")==0){
                gtk_label_set_text(GTK_LABEL(output),"Ce numéro est invalide!");
                                }
        else if(strcmp(a.password,"")==0 ||strcmp(a.cin,"")==0 ||strcmp(a.login,"")==0 ||strcmp(a.nom,"")==0||strcmp(a.prenom,"")==0||strcmp(a.num,"")==0){
                gtk_label_set_text(GTK_LABEL(output),"veuillez remplir toutes les cases");
                }
        else if((verifier_agent(log)!=-1)){
                gtk_label_set_text(GTK_LABEL(output),"ce login est déja utilisé");
                }
        else if(strcmp(a.password,pswd)!=0){
                gtk_label_set_text(GTK_LABEL(output),"mots de passess non identiques");
                }
        else
        {
        ajouter_agent(a);
        gtk_label_set_text(GTK_LABEL(output),"");
        gtk_widget_show_all(valide);
        }
}


void on_bchercher1_clicked    (GtkButton       *object_graphique, gpointer         user_data)
{
GtkWidget *login,*nom,*prenom,*cin,*num,*password,*valide,*output3;//chercher l'utilisateur
agent u ;
char l[20];
FILE*f;
output3=lookup_widget(object_graphique,"message4");
login=lookup_widget(object_graphique, "clogin2");
password=lookup_widget(object_graphique, "cpassword2");
cin=lookup_widget(object_graphique, "ccin2");
nom=lookup_widget(object_graphique, "cnom2");
prenom=lookup_widget(object_graphique, "cprenom2");
num=lookup_widget(object_graphique, "cnum2");


strcpy(l,gtk_entry_get_text(GTK_ENTRY(login)));

if(strcmp(l,"")==0){
gtk_label_set_text(GTK_LABEL(output3),"entrer un login");
}
else
if(rechercher_agent(u,l)==0){
gtk_label_set_text(GTK_LABEL(output3),"agent introuvable");
gtk_entry_set_text(GTK_ENTRY(login),"");
gtk_entry_set_text(GTK_ENTRY(nom),"");
gtk_entry_set_text(GTK_ENTRY(prenom),"");
gtk_entry_set_text(GTK_ENTRY(num),"");
gtk_entry_set_text(GTK_ENTRY(cin),"");
gtk_entry_set_text(GTK_ENTRY(password),"");
}
else
if(rechercher_agent(u,l)==1){
        f=fopen("agent.bin","rb+");
        if(f!=NULL){
                while(!(feof(f)))
                {
                        fread(&u,sizeof(agent),1,f);
                        if(strcmp(u.login,l)==0)
                        {
                                gtk_entry_set_text(GTK_ENTRY(login),u.login);
                                gtk_entry_set_text(GTK_ENTRY(nom),u.nom);
                                gtk_entry_set_text(GTK_ENTRY(prenom),u.prenom);
                                gtk_entry_set_text(GTK_ENTRY(num),u.num);
                                gtk_entry_set_text(GTK_ENTRY(cin),u.cin);
                                gtk_entry_set_text(GTK_ENTRY(password),u.password);
                                break;
                        }
                }
        }

        fclose(f);

}
}



void
on_bmodifier1_clicked                  (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *login,*nom,*prenom,*cin,*num,*password,*modif,*output3;//modifier utilisateur utilisateur 
agent u ;
char l[20];
modif=create_modifiersucc();
output3=lookup_widget(object_graphique,"message4");
login=lookup_widget(object_graphique, "clogin2");
password=lookup_widget(object_graphique, "cpassword2");
cin=lookup_widget(object_graphique, "ccin2");
nom=lookup_widget(object_graphique, "cnom2");
prenom=lookup_widget(object_graphique, "cprenom2");
num=lookup_widget(object_graphique, "cnum2");

strcpy(l,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(u.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.password,gtk_entry_get_text(GTK_ENTRY(password)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(u.num,gtk_entry_get_text(GTK_ENTRY(num)));
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
if(strcmp(u.num,"0")==0){
gtk_label_set_text(GTK_LABEL(output3),"Ce numéro est invalide!");
}
else if(strcmp(u.login,"")==0 ||strcmp(u.nom,"")==0||strcmp(u.prenom,"")==0||strcmp(u.num,"")==0){
gtk_label_set_text(GTK_LABEL(output3),"veuillez remplir toutes les cases");

}
else {modifier_agent (u ,l);

gtk_entry_set_text(GTK_ENTRY(login),"");
gtk_entry_set_text(GTK_ENTRY(nom),"");
gtk_entry_set_text(GTK_ENTRY(prenom),"");
gtk_entry_set_text(GTK_ENTRY(num),"");
gtk_entry_set_text(GTK_ENTRY(cin),"");
gtk_entry_set_text(GTK_ENTRY(password),"");

}
gtk_widget_show_all(modif);
}


void
on_bsupprimer1_clicked                 (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*output,*suppr;
char login[20];
agent u;
suppr=create_supprimersucc();
input2=lookup_widget(object_graphique,"csupprimer1");
output=lookup_widget(object_graphique,"message3");

strcpy(login,gtk_entry_get_text(GTK_ENTRY(input2)));


if(strcmp(login,"")==0){
gtk_label_set_text(GTK_LABEL(output),"entrer un login");
}
else{
if(rechercher_agent(u,login)!=0){
supprimer_agent(u,login);
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_label_set_text(GTK_LABEL(output),"");
gtk_widget_show(suppr);
}
else{
gtk_label_set_text(GTK_LABEL(output),"agent inexistant");
}
}
}


void
on_bmodifier2_clicked                  (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *modifier;
modifier=lookup_widget(object_graphique,"modifersucc");
gtk_widget_hide(modifier);
}


void
on_bsupprimer2_clicked                 (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *sup;
sup=lookup_widget(object_graphique,"supprimersucc");
gtk_widget_hide(sup);
}


void
on_bgestag_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"menuadmin");
gtk_widget_hide(window3);
window4=create_gestagents();
gtk_widget_show_all(window4);
}


void
on_bajoutsucc_clicked                  (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *aj;
aj=lookup_widget(object_graphique,"ajoutsucc");
gtk_widget_hide(aj);
}


void
on_bclear1_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *taff;
taff=lookup_widget(object_graphique,"taff");
clear_agent();
afficher_agent(taff);
}


void
on_binscription1_clicked               (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
       GtkWidget *login,*nom,*prenom,*num,*cin,*password,*valide,*output;//ajout agent 
        client a;
        int k=0;
        char log[30],pswd[30];
        output=lookup_widget(object_graphique,"message5");
        valide=create_inscritsucc();
        nom=lookup_widget(object_graphique, "cnom3");
        prenom=lookup_widget(object_graphique, "cprenom3");
        num=lookup_widget(object_graphique,"cnum3");
        cin=lookup_widget(object_graphique, "ccin3");
        login=lookup_widget(object_graphique, "clogin3");
        password=lookup_widget(object_graphique, "cpassword3");

        strcpy(a.login,gtk_entry_get_text(GTK_ENTRY(login)));
        strcpy(log,gtk_entry_get_text(GTK_ENTRY(login)));
        strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(a.num,gtk_entry_get_text(GTK_ENTRY(num)));
        strcpy(a.password,gtk_entry_get_text(GTK_ENTRY(password)));
        if(strcmp(a.num,"0")==0){
                gtk_label_set_text(GTK_LABEL(output),"Ce numéro est invalide!");
                                }
        else if(strcmp(a.password,"")==0 ||strcmp(a.cin,"")==0 ||strcmp(a.login,"")==0 ||strcmp(a.nom,"")==0||strcmp(a.prenom,"")==0||strcmp(a.num,"")==0){
                gtk_label_set_text(GTK_LABEL(output),"veuillez remplir toutes les cases");
                }
        else
        {
        ajouter_client(a);
        gtk_label_set_text(GTK_LABEL(output),"");
        gtk_widget_show_all(valide);
        }
}


void
on_bclear2_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{

}


void
on_bretour2_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"inscritclient");
gtk_widget_hide(window3);
window4=create_acceuil();
gtk_widget_show_all(window4);
}


void
on_bagent1_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *aj;
aj=lookup_widget(object_graphique,"agent");
gtk_widget_hide(aj);
}


void
on_bclient1_clicked                    (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *aj;
aj=lookup_widget(object_graphique,"client");
gtk_widget_hide(aj);
}


void
on_binscritsucc_clicked                (GtkButton       *object_graphique,
                                        gpointer         user_data)
{
GtkWidget *aj;
aj=lookup_widget(object_graphique,"inscritsucc");
gtk_widget_hide(aj);
}

