#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "client.h"

enum   
{   LOGIN,
	NOM,
    PRENOM,
    CIN,
	NUM,
	PASSWORD,
    COLUMNS
};
void afficher_client(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

		client a; 
        store=NULL;
        int j=0,i=0;
       FILE *f;
	
	store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("login", renderer, "text",LOGIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" nom", renderer, "text",NOM, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  prenom", renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  cin", renderer, "text",CIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  numero", renderer, "text",NUM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  password", renderer, "text",PASSWORD, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

               
	
	}

	store=gtk_list_store_new (COLUMNS,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("client.bin","rb");

	if(f==NULL)
	{

		return;
	}		
	else 

	{ 	while(!(feof(f)))
		{
			i++;
			fread(&a,sizeof(client),1,f);

		}
	fclose(f);
	f=fopen("client.bin","rb");
	while(j<i-1)
		{j++;
	fread(&a,sizeof(client),1,f);
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, LOGIN, a.login, NOM, a.nom, PRENOM, a.prenom,CIN,a.cin,NUM,a.num,PASSWORD,a.password, -1); 
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}
void ajouter_client(client a)
{
	FILE *f;
	f=fopen("client.bin","ab+");

	if (f!=NULL)
		{
			fwrite(&a,sizeof(client),1,f);

		}
	fclose(f);
}

int supprimer_client(client a,char login[30])
{
	FILE *f,*c;
	int i=0,j=0;
	f=fopen("client.bin","rb");
	c=fopen("tempclient.bin","ab");
	while(!(feof(f)))
		{
			i++;
			fread(&a,sizeof(client),1,f);

		}
	fclose(f);
	f=fopen("client.bin","rb");
	while(j<i-1)
	{
		j++;
		fread(&a,1,sizeof(client),f);
		if(strcmp(a.login,login)!=0)
			{
				fwrite(&a,sizeof(client),1,c);
			}
	}
	fclose(c);
	fclose(f);
	remove("client.bin");
	rename("tempclient.bin","client.bin");

}
int rechercher_client(client a,char login[30])
{
	int i=0;
	FILE*f;
	f=fopen("client.bin","rb+");
	if(f!=NULL){
		while(!(feof(f)))
		{
			fread(&a,sizeof(client),1,f);
			if(strcmp(a.login,login)==0)
			{
				i++;
				break;
			}
		}
	}
	fclose(f);
	return i;
}
int verifier_client(char login[30])
{	FILE *f,*b,*i;
client a={"med","rez","099","21234567","med","12345"},g;
int k=-1;
if (strcmp(a.login,login)==0)
{
	return 1;
}
else
	{b=fopen("client.bin","rb+");

if (b!=NULL)
		{

			while(!(feof(b)))
				{
				fread(&g,sizeof(client),1,b);
				if (strcmp(g.login,login)==0)
					{
						return 2;
					}


				}
		}
fclose(b);}

return k;
}
void modifier_client(client a,char login[30])
{
	supprimer_client(a,login);
	ajouter_client(a);
}
void clear_client()
{	FILE *f;
	remove("client.bin");
	f=fopen("client.bin","wb");
	fclose(f);
}


