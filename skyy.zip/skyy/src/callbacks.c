#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include "voiture.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"


voiture voiture_selectioner;
voiture voitureselect;
/**************************************************/
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))//
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data, -1);
  }

strcpy(voiture_selectioner.Numero_de_serie,str_data);
FILE *f ;
f=fopen("voiture.bin","rb");
struct voiture v;
while (!feof(f))
{
fread(&v,1,sizeof(v),f);
if (strcmp(voiture_selectioner.Numero_de_serie,v.Numero_de_serie)==0) voiture_selectioner=v;

}



fclose(f);
}

/**************************************************/
void
on_Supp_voiture_clicked                (GtkWidget      *objet,
                           gpointer       user_data)
{
supp_voit((char *) voiture_selectioner.Numero_de_serie);
GtkWidget *tree;tree=lookup_widget(objet,"treeview1");
afficher1(tree);
}


/**************************************************/
void
on_Modif_voiture_clicked               (GtkWidget      *objet,
                           gpointer       user_data)
{
GtkWidget *Modif_location_voiture_interface,*Gestion_Location_voiture_interface,*out;

Modif_location_voiture_interface=create_Modif_location_voiture_interface();

Gestion_Location_voiture_interface=lookup_widget(objet,"Gestion_Location_voiture_interface");
gtk_widget_destroy(Gestion_Location_voiture_interface);
gtk_widget_show(Modif_location_voiture_interface);
out=lookup_widget(Modif_location_voiture_interface,"entry12");
gtk_entry_set_text (out,voiture_selectioner.Marque);
out=lookup_widget(Modif_location_voiture_interface,"entry13");
gtk_entry_set_text (out,voiture_selectioner.Modele);
out=lookup_widget(Modif_location_voiture_interface,"entry14");
gtk_entry_set_text (out,voiture_selectioner.Numero_de_serie);
out=lookup_widget(Modif_location_voiture_interface,"entry15");
gtk_entry_set_text (out,voiture_selectioner.Prix);


}

/**************************************************/
void
on_Ajouter_Voiture_clicked             (GtkWidget      *objet,
                           gpointer       user_data)
{
GtkWidget *Ajout_location_voiture_interface,*Gestion_Location_voiture_interface;
Ajout_location_voiture_interface=create_Ajout_location_voiture_interface();
Gestion_Location_voiture_interface=lookup_widget(objet,"Gestion_Location_voiture_interface");
gtk_widget_destroy(Gestion_Location_voiture_interface);
gtk_widget_show(Ajout_location_voiture_interface);

}

/**************************************************/
void
on_button_retour_gest_prest_clicked    (GtkWidget      *objet,
                           gpointer       user_data)
{
GtkWidget *Acceuil_Location_Voiture,*Gestion_Location_voiture_interface;
Acceuil_Location_Voiture=create_Acceuil_Location_Voiture();
Gestion_Location_voiture_interface=lookup_widget(objet,"Gestion_Location_voiture_interface");
gtk_widget_destroy(Gestion_Location_voiture_interface);
gtk_widget_show(Acceuil_Location_Voiture);

}

/**************************************************/
void
on_Retour_gest_voiture_clicked         (GtkWidget      *objet,
                           gpointer       user_data)
{
GtkWidget *Ajout_location_voiture_interface;
GtkWidget *Gestion_Location_voiture_interface;
GtkWidget *treeview1;

Ajout_location_voiture_interface=lookup_widget(objet,"Ajout_location_voiture_interface");


Gestion_Location_voiture_interface=lookup_widget(objet,"Gestion_Location_voiture_interface");
Gestion_Location_voiture_interface=create_Gestion_Location_voiture_interface();

gtk_widget_destroy(Ajout_location_voiture_interface);

gtk_widget_show(Gestion_Location_voiture_interface);

treeview1=lookup_widget(Gestion_Location_voiture_interface,"treeview1");

afficher1(treeview1);
}

/**************************************************/
void
on_Ajout_voiture_clicked     (GtkWidget      *objet,
                           gpointer       user_data)        

{ GtkWidget *a,*b,*c, *e , *l1, *l ,*List_View ;

	struct voiture v;
	
	a=lookup_widget(objet,"entry7");
	b=lookup_widget(objet,"entry8");
	c=lookup_widget(objet,"entry9");
	e=lookup_widget(objet,"entry11");

	strcpy(v.Marque,gtk_entry_get_text(GTK_ENTRY(a)));

	strcpy(v.Modele,gtk_entry_get_text(GTK_ENTRY(b)));
        strcpy(v.Numero_de_serie,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(v.Prix,gtk_entry_get_text(GTK_ENTRY(e)));
 
        ajouter_loc(v);

	l=create_Gestion_Location_voiture_interface();

	l1=lookup_widget(objet,"Ajout_location_voiture_interface");
	gtk_widget_destroy (l1);

	List_View=lookup_widget(l,"treeview1");
	afficher1(List_View);
	gtk_widget_show (l);
	GtkWidget *dialog1;
	dialog1=create_dialog1();
	gtk_widget_show(dialog1);

}

/**************************************************/

void
on_Valider_modif_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *a,*b,*c, *e , *l1, *l ,*List_View ;

supp_voit(voiture_selectioner.Numero_de_serie);
	struct voiture voiture_selectioner;
	
	a=lookup_widget(objet,"entry12");
	b=lookup_widget(objet,"entry13");
	c=lookup_widget(objet,"entry14");
	e=lookup_widget(objet,"entry15");

	strcpy(voiture_selectioner.Marque,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(voiture_selectioner.Modele,gtk_entry_get_text(GTK_ENTRY(b)));
        strcpy(voiture_selectioner.Numero_de_serie,gtk_entry_get_text(GTK_ENTRY(c)));
	strcpy(voiture_selectioner.Prix,gtk_entry_get_text(GTK_ENTRY(e)));
 
        ajouter_loc(voiture_selectioner);
	l=create_Gestion_Location_voiture_interface();

	l1=lookup_widget(objet,"Modif_location_voiture_interface");
	gtk_widget_destroy(l1);

	List_View=lookup_widget(l,"treeview1");
	afficher1(List_View);
	gtk_widget_show (l);

}
/**************************************************/


void
on_Rechercher_voiture_clicked          (GtkWidget     *objet,
                                        gpointer         user_data)
{
GtkWidget *i1,*i2,*i3,*List;
        i1=lookup_widget(objet,"entry1");
	i2=lookup_widget(objet,"entry2");
	i3=lookup_widget(objet,"entry3");
List=lookup_widget(objet,"treeview1");
afficher_rechercher(List,gtk_entry_get_text(GTK_ENTRY(i1)) ,gtk_entry_get_text(GTK_ENTRY(i2)),gtk_entry_get_text(GTK_ENTRY(i3)));

}
/**************************************************/
void
on_agentbtn_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{ 
GtkWidget *Acceuil_Location_Voiture,*Gestion_Location_voiture_interface,*treeview1;

Acceuil_Location_Voiture=lookup_widget(objet,"Acceuil_Location_Voiture");
Gestion_Location_voiture_interface=lookup_widget(objet,"Gestion_Location_voiture_interface");
Gestion_Location_voiture_interface=create_Gestion_Location_voiture_interface();
gtk_widget_destroy(Acceuil_Location_Voiture);
gtk_widget_show(Gestion_Location_voiture_interface);
treeview1=lookup_widget(Gestion_Location_voiture_interface,"treeview1");
afficher1(treeview1);
}

/**************************************************/
void
on_Clientbtn_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_Location_Voiture,*Location_voiture_interface,*treeview1;

Acceuil_Location_Voiture=lookup_widget(objet,"Acceuil_Location_Voiture");
Location_voiture_interface=lookup_widget(objet,"Location_voiture_interface");
Location_voiture_interface=create_Location_voiture_interface();
gtk_widget_destroy(Acceuil_Location_Voiture);
gtk_widget_show(Location_voiture_interface);
treeview1=lookup_widget(Location_voiture_interface,"treeview2");
afficher1(treeview1);
}
/**************************************************/

void
on_Quitbtn_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_Location_Voiture;
Acceuil_Location_Voiture=lookup_widget(objet,"Acceuil_Location_Voiture");
gtk_widget_destroy(Acceuil_Location_Voiture);
}

/**************************************************/
void
on_Retour_client_to_acceuil_clicked    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_Location_Voiture,*Location_voiture_interface;

Acceuil_Location_Voiture=create_Acceuil_Location_Voiture();
Location_voiture_interface=lookup_widget(objet,"Location_voiture_interface");
gtk_widget_destroy(Location_voiture_interface);
gtk_widget_show(Acceuil_Location_Voiture);
}
/*********************************************************************************************************************/
void
on_Ok_mes_reservations_activate        (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *Location_voiture_interface,*Mes_reservations_interface;

Location_voiture_interface=create_Location_voiture_interface();
Mes_reservations_interface=lookup_widget(objet,"Mes_reservations_interface");
gtk_widget_destroy(Mes_reservations_interface);
gtk_widget_show(Location_voiture_interface);
}
/*****************************************************************************************************************/
void
on_Mes_reservations_activate           (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *l3, *l2 ,*List_View3 ;

	l2=create_Mes_reservations_interface();

	l3=lookup_widget(objet,"Mes_reservations_interface");
        //l2=afficher2(List_View3);

	
	List_View3=lookup_widget(l2,"treeview3");

	afficher2(List_View3);

	gtk_widget_show (l2);




}

/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/


void
on_Reserver_voit_clicked               (GtkWidget     *objet,
                                        gpointer         user_data)
{
GtkWidget *Jour,*Mois,*Annee,*Nbjr;

struct Reservationvoiture Reservationvoiture;

Jour=lookup_widget(objet,"jour_de");
Mois=lookup_widget(objet,"mois_de");
Annee=lookup_widget(objet,"anne_de");
Nbjr=lookup_widget(objet,"nbjr");

Reservationvoiture.dt_resr.jour_de=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Jour));
Reservationvoiture.dt_resr.mois_de=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Mois));
Reservationvoiture.dt_resr.anne_de=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Annee));
Reservationvoiture.nb_jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Nbjr));
strcpy(Reservationvoiture.voiture_2.Marque,voitureselect.Marque);
strcpy(Reservationvoiture.voiture_2.Modele,voitureselect.Modele);
strcpy(Reservationvoiture.voiture_2.Prix,voitureselect.Prix);
strcpy(Reservationvoiture.voiture_2.Numero_de_serie,voitureselect.Numero_de_serie);


ajouter_reservation(Reservationvoiture);

}




void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  { 
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data, -1);
  }

strcpy(voitureselect.Numero_de_serie,str_data);
FILE *f ;
f=fopen("voiture.bin","rb");
struct voiture v2;
while (!feof(f))
{
fread(&v2,1,sizeof(v2),f);
if (strcmp(voitureselect.Numero_de_serie,v2.Numero_de_serie)==0) voitureselect=v2;
}
fclose(f);
}




