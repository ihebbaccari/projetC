#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"
struct Date
{
int jour_de;
int mois_de;
int anne_de;
};
typedef struct Date Date; 

struct voiture
{char Marque[20];
 char Modele[20];
char Numero_de_serie[20];
char Prix[20];
};
typedef struct voiture voiture;

/***********************************/
 struct Reservationvoiture
{voiture voiture_2;
Date dt_resr;
int nb_jour;
};
typedef struct Reservationvoiture Reservationvoiture;


//

void ajouter_reservation(Reservationvoiture Res);
void ajouter_loc(voiture v);
void afficher1(GtkWidget *List);
void afficher2(GtkWidget *List);
void supp_voit(char Numero_de_serie[]);
void afficher_rechercher(GtkWidget *List,char c1[] ,char c2[],char c3[]);




