#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Supp_voiture_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Rechercher_voiture_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Modif_voiture_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Ajouter_Voiture_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button_retour_gest_prest_clicked    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Retour_gest_voiture_clicked         (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Ajout_voiture_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Valider_modif_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Mes_reservation_voiture_client_clicked
                                        (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Reserver_voit_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Rechercher_voiture_clicked          (GtkWidget     *objet,
                                        gpointer         user_data);

void
on_Valider_reserv_clicked              (GtkWidget      *objet,
                                        gpointer         user_data);


void
on_Retour_location_voiture_clicked     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_agentbtn_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Clientbtn_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Quitbtn_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Retour_client_to_acceuil_clicked    (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Mes_reservations_activate           (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_Ok_mes_reservations_activate        (GtkWidget      *objet,
                                        gpointer         user_data);
