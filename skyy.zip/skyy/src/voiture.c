#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#include "voiture.h"

/******************* fct ajouter ****************/

void ajouter_loc(voiture v)
{
FILE *f;
f=fopen("voiture.bin","ab");
if(f!=NULL)
	{
	fwrite(&v,sizeof(v),1,f);
	}
fclose(f);

}

/******************* fct afficher ****************/
enum { COL_MARQUE,
       COL_MODELE,
       COL_NUMERO_DE_SERIE,
       COL_PRIX,
       COL_COLUMNS
      };

void afficher1(GtkWidget *List)
{ 


GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

store=gtk_tree_view_get_model(List);
  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Marque", renderer, "text",COL_MARQUE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Modele", renderer, "text",COL_MODELE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Numero_de_serie", renderer, "text", COL_NUMERO_DE_SERIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prix", renderer, "text", COL_PRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	


	
	}
	store=gtk_list_store_new (COL_COLUMNS, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

struct voiture v;
FILE *f;

f=fopen("voiture.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&v,1,sizeof(v),f);
i++;
}
fclose(f);

f=fopen("voiture.bin","rb");
if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&v,1,sizeof(v),f);
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, COL_MARQUE,v.Marque, COL_MODELE,v.Modele, COL_NUMERO_DE_SERIE,v.Numero_de_serie, COL_PRIX,
v.Prix, -1);}

 j++;
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (List),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}

}
/**********************fct supp********************/
void supp_voit(char Numero_de_serie[])
{
FILE *f;
FILE *d;
f=fopen("voiture.bin","rb");
d=fopen("voituretmp.bin","wb");
fclose(d);
d=fopen("voituretmp.bin","ab");
if(f!=NULL&&d!=NULL)
{
struct voiture v;
while(!(feof(f)))
{
fread(&v,1,sizeof(voiture),f);
if(strcmp(v.Numero_de_serie,Numero_de_serie)!=0)
	{
	fwrite(&v,sizeof(voiture),1,d);
	}

}

}
fclose(f);
fclose(d);
remove("/home/bouzayen/Desktop/skyy/src/voiture.bin");
rename("/home/bouzayen/Desktop/skyy/src/voituretmp.bin","/home/bouzayen/Desktop/skyy/src/voiture.bin");


}
/**********************fct recherche**************************/

void afficher_rechercher(GtkWidget *List,char c1[] ,char c2[],char c3[])
{ GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

store=gtk_tree_view_get_model(List); 
  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Marque", renderer, "text",COL_MARQUE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Modele", renderer, "text",COL_MODELE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Numero_de_serie", renderer, "text", COL_NUMERO_DE_SERIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prix", renderer, "text", COL_PRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	


	
	}
	store=gtk_list_store_new (COL_COLUMNS, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

struct voiture v;
FILE *f;

f=fopen("voiture.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&v,1,sizeof(v),f);
i++;
}
fclose(f);

f=fopen("voiture.bin","rb");
		if(strcmp(c1,"")==0&&strcmp(c2,"")==0&&strcmp(c3,"")==0)
{if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&v,1,sizeof(v),f);
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, COL_MARQUE,v.Marque, COL_MODELE,v.Modele, COL_NUMERO_DE_SERIE,v.Numero_de_serie, COL_PRIX,
v.Prix, -1);}

 j++;
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (List),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}}

else
{if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&v,1,sizeof(v),f);


		if(strcmp(v.Marque,c1)==0||strcmp(v.Modele,c2)==0||strcmp(v.Numero_de_serie,c3)==0)
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, COL_MARQUE,v.Marque, COL_MODELE,v.Modele, COL_NUMERO_DE_SERIE,v.Numero_de_serie, COL_PRIX,
v.Prix, -1);}

 j++;
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (List),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}}
}

/********************************************************************************************************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/**************************************************/
/***********************fct ajout date reservation******************/
void ajouter_reservation(Reservationvoiture r)
{
FILE *f;
f=fopen("voiturereser.bin","ab");
if(f!=NULL)
	{
	fwrite(&r,sizeof(Reservationvoiture),1,f);
fclose(f);
	}


}
/******************* fct afficher mes reservation ****************/
enum { CL_MARQUE,
       CL_MODELE,
       CL_NUMERO_DE_SERIE,
       CL_PRIX,
	CL_DATE,
       CL_COLUMNS
      };

void afficher2(GtkWidget *List)
{ 


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

store=gtk_tree_view_get_model(List);
  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Marque", renderer, "text",CL_MARQUE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Modele", renderer, "text",CL_MODELE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Numero_de_serie", renderer, "text", CL_NUMERO_DE_SERIE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prix", renderer, "text", CL_PRIX, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);
	
        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Marque", renderer, "text",CL_MARQUE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Date", renderer, "text",CL_DATE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (List), column);

	
	}
	store=gtk_list_store_new (CL_COLUMNS, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);

struct voiture v2;
FILE *f;

f=fopen("voiture2.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&v2,1,sizeof(v2),f);
i++;
}
fclose(f);

f=fopen("voiture2.bin","rb");
if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&v2,1,sizeof(v2),f);
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, CL_MARQUE,v2.Marque, CL_MODELE,v2.Modele, CL_NUMERO_DE_SERIE,v2.Numero_de_serie, CL_PRIX,
v2.Prix, -1);}

 j++;
		}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (List),  GTK_TREE_MODEL (store));
        g_object_unref (store);
	}
}

